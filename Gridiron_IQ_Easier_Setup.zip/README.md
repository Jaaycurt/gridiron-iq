# Gridiron IQ — one-time setup and automatic updates

## What you do vs. what the app does

**You upload the app files once.** After that, GitHub Actions runs automatically every six hours during NFL season. Each run downloads available stats, news, and weather data, validates it, then publishes the website and refreshed JSON files to GitHub Pages in one deployment. You do not upload stats manually every week, and you do not need to open the website to trigger the job.

## One-time setup

1. On GitHub, create a **public** repository named `gridiron-iq`. A public repo is needed for GitHub Pages on the free GitHub plan. Don't put private/personal information in the repository.
2. Download and unzip this package on your computer. Upload the *contents* of the ZIP (not the ZIP file itself) into the top level of the repository. Make sure the `.github/workflows/refresh-and-deploy.yml` file and the `scripts` folder are included.
3. In your repository, click **Settings → Pages**. Under **Build and deployment → Source**, select **GitHub Actions**.
4. Click the **Actions** tab. Open **Refresh NFL data and publish Gridiron IQ** and click **Run workflow** to test the first update.
5. Wait for a green check mark. Open the successful run and check that all steps, especially "Build NFL stats", "Build NFL news and game weather", and "Deploy site and refreshed data", passed.
6. Return to **Settings → Pages** and open **Visit site** once GitHub provides the site URL. The URL looks like `https://YOUR-USERNAME.github.io/gridiron-iq/`.
7. On your iPhone, open that URL in Safari → Share → **Add to Home Screen**. Use that same icon each week.

## How automatic uploading works

- GitHub Actions is the background computer that runs the workflow.
- It downloads the current public NFL data releases and news/weather sources.
- It creates `data/stats.json`, `data/news.json`, and `data/weather.json`.
- It deploys the website and these generated files together. This is important: GitHub Pages is configured to deploy via **GitHub Actions**, so the new data files actually get published on each scheduled run.
- The schedule runs every six hours during the NFL season months configured in the workflow. GitHub may delay scheduled jobs; it is not a guaranteed real-time feed.
- The website itself is static. It does not run a server in the background on your phone.

## How to check that it is working

1. Open **GitHub → your repository → Actions**.
2. Look for "Refresh NFL data and publish Gridiron IQ".
3. A green check means the job completed. A red X means it failed; open it to read the failed step.
4. After a successful deployment, open your site and visit **Sync**, **News**, or **Weather**. The status line shows the last data build time.
5. If the app is already open, refresh the browser page to load the newest published data.

## Data source and limitations

- NFL weekly player/team statistics: public nflverse CSV releases.
- News: ESPN NFL editorial feed; injury labels are inferred from headlines and summaries, not an official complete injury report.
- Game weather: nflverse schedule and Open-Meteo forecasts; forecasts are estimates and only reliable a short time ahead.
- The build fails rather than intentionally publishing empty player stats, empty news, or an empty upcoming schedule.
- If the upstream source changes or temporarily fails, the workflow may fail and require a later retry.
