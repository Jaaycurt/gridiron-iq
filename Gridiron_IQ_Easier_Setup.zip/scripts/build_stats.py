#!/usr/bin/env python3
import csv, io, json, os, sys
from datetime import datetime, timezone
from urllib.request import Request, urlopen

SEASON = int(os.environ.get("NFL_SEASON", datetime.now(timezone.utc).year))
BASE = "https://github.com/nflverse/nflverse-data/releases/download"
TEAM_CODES = set("ARI ATL BAL BUF CAR CHI CIN CLE DAL DEN DET GB HOU IND JAX KC LAC LAR LV MIA MIN NE NO NYG NYJ PHI PIT SEA SF TB TEN WAS".split())
OFFENSE = {"QB", "RB", "WR", "TE", "FB"}
DEFENSE = {"DB", "CB", "S", "FS", "SS", "SAF", "LB", "ILB", "OLB", "DL", "DE", "DT", "NT", "EDGE"}
def num(row, *keys):
    for key in keys:
        value = row.get(key)
        if value not in (None, ""):
            try: return float(value)
            except (ValueError, TypeError): pass
    return 0
def text(row, *keys):
    for key in keys:
        v = row.get(key)
        if v is not None and str(v).strip(): return str(v).strip()
    return ""
def get_csv(url):
    req = Request(url, headers={"User-Agent":"GridironIQ/1.0"})
    with urlopen(req, timeout=90) as response:
        raw = response.read()
    # Some releases use UTF-8 BOM.
    return list(csv.DictReader(io.StringIO(raw.decode("utf-8-sig"))))
def nfl_position(row):
    pos = text(row, "position", "pos").upper()
    group = text(row, "position_group").upper()
    if pos in {"QB","RB","WR","TE"}: return pos
    # Only label defensive positions as DEF when a defense stat is present.
    defensive_volume = sum(num(row, k) for k in (
        "def_tackles_solo","def_tackles_with_assist","def_sacks","def_interceptions",
        "def_pass_defended","def_fumbles_forced","def_fumbles_recovered","def_tds"
    ))
    if pos in DEFENSE or group in {"DEF","DB","LB","DL"}:
        return "DEF" if defensive_volume > 0 or pos in DEFENSE else ""
    return ""
def build_player(row, season):
    pos = nfl_position(row)
    name = text(row, "player_display_name", "player_name", "name")
    team = text(row, "recent_team", "team").upper()
    week = int(num(row, "week"))
    row_season = int(num(row, "season") or season)
    if not pos or not name or team not in TEAM_CODES or not week: return None
    player_id = text(row, "player_id", "gsis_id") or name
    return {
      "id":0,"source":"nflverse","sourceKey":f"nflverse:{row_season}:{week}:{player_id}:{team}",
      "name":name,"team":team,"position":pos,"season":row_season,"week":week,"gamesPlayed":1,
      "comp":num(row,"completions"),"att":num(row,"attempts"),
      "passYds":num(row,"passing_yards"),"passTD":num(row,"passing_tds"),
      "ints":num(row,"interceptions","passing_interceptions","def_interceptions"),
      "rushAtt":num(row,"carries"),"rushYds":num(row,"rushing_yards"),"rushTD":num(row,"rushing_tds"),
      "rec":num(row,"receptions"),"recYds":num(row,"receiving_yards"),"recTD":num(row,"receiving_tds"),
      "targets":num(row,"targets"),"fumbles":num(row,"rushing_fumbles")+num(row,"receiving_fumbles"),
      "tackles":num(row,"def_tackles_solo")+num(row,"def_tackles_with_assist"),
      "soloTackles":num(row,"def_tackles_solo"),"sacks":num(row,"def_sacks","sacks"),
      "passesDefended":num(row,"def_pass_defended"),"forcedFumbles":num(row,"def_fumbles_forced"),
      "fumbleRecoveries":num(row,"def_fumbles_recovered"),"defTD":num(row,"def_tds")
    }
def main():
    players_url=f"{BASE}/stats_player/stats_player_week_{SEASON}.csv"
    team_url=f"{BASE}/stats_team/stats_team_week_{SEASON}.csv"
    players_raw=get_csv(players_url)
    player_rows=[]
    for r in players_raw:
        if text(r,"season_type").upper() not in ("","REG"): continue
        obj=build_player(r,SEASON)
        if obj: player_rows.append(obj)
    teams=[]
    try:
        team_raw=get_csv(team_url)
        for r in team_raw:
            if text(r,"season_type").upper() not in ("","REG"): continue
            team=text(r,"team","recent_team","team_abbr").upper()
            week=int(num(r,"week")); season=int(num(r,"season") or SEASON)
            if team not in TEAM_CODES or not week: continue
            teams.append({
              "id":0,"source":"nflverse","sourceKey":f"nflverse-team:{season}:{week}:{team}",
              "team":team,"season":season,"week":week,"wins":num(r,"wins"),"losses":num(r,"losses"),
              "pointsFor":num(r,"points","points_for","team_points"),
              "pointsAgainst":num(r,"opponent_points","points_against"),
              "totalYards":num(r,"total_yards","yards_gained"),
              "passYards":num(r,"passing_yards"),"rushYards":num(r,"rushing_yards"),
              "turnoverDiff":num(r,"turnover_differential","turnover_diff"),
              "teamSacks":num(r,"sacks_suffered","sacks_allowed"),
              "takeaways":num(r,"takeaways"),"thirdDown":num(r,"third_down_pct","third_down_percentage"),
              "redZone":num(r,"red_zone_pct","redzone_pct")
            })
    except Exception as exc:
        print(f"WARNING: team data unavailable: {exc}", file=sys.stderr)
    if len(player_rows) < 1:
        raise RuntimeError(f"Safety check failed: only {len(player_rows)} player rows were parsed; refusing to publish empty data.")
    if len(set(x["sourceKey"] for x in player_rows)) != len(player_rows):
        raise RuntimeError("Safety check failed: duplicate player keys detected.")
    payload={"schemaVersion":1,"season":SEASON,"generatedAt":datetime.now(timezone.utc).isoformat(),"source":"nflverse public releases","players":player_rows,"teams":teams}
    os.makedirs("data",exist_ok=True)
    with open("data/stats.json","w",encoding="utf-8") as f: json.dump(payload,f,separators=(",",":"))
    print(f"Published build: season={SEASON}, players={len(player_rows)}, teams={len(teams)}")
if __name__=="__main__": main()
