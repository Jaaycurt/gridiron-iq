#!/usr/bin/env python3
import csv, io, json, re, time
from datetime import datetime, timezone, date, timedelta
from urllib.request import Request, urlopen
from urllib.parse import urlencode
from pathlib import Path

ROOT=Path("data")
UA="GridironIQ/1.0"
STADIUMS={
"ARI":(33.5276,-112.2626,"State Farm Stadium","retractable"),"ATL":(33.7554,-84.4008,"Mercedes-Benz Stadium","dome"),
"BAL":(39.2780,-76.6227,"M&T Bank Stadium","outdoors"),"BUF":(42.7738,-78.7870,"Highmark Stadium","outdoors"),
"CAR":(35.2258,-80.8528,"Bank of America Stadium","outdoors"),"CHI":(41.8623,-87.6167,"Soldier Field","outdoors"),
"CIN":(39.0954,-84.5160,"Paycor Stadium","outdoors"),"CLE":(41.5061,-81.6995,"Huntington Bank Field","outdoors"),
"DAL":(32.7473,-97.0945,"AT&T Stadium","retractable"),"DEN":(39.7439,-105.0201,"Empower Field at Mile High","outdoors"),
"DET":(42.3400,-83.0456,"Ford Field","dome"),"GB":(44.5013,-88.0622,"Lambeau Field","outdoors"),
"HOU":(29.6847,-95.4107,"NRG Stadium","retractable"),"IND":(39.7601,-86.1639,"Lucas Oil Stadium","retractable"),
"JAX":(30.3239,-81.6373,"EverBank Stadium","outdoors"),"KC":(39.0489,-94.4839,"GEHA Field at Arrowhead Stadium","outdoors"),
"LV":(36.0909,-115.1833,"Allegiant Stadium","dome"),"LAC":(33.9535,-118.3392,"SoFi Stadium","dome"),
"LAR":(33.9535,-118.3392,"SoFi Stadium","dome"),"MIA":(25.9580,-80.2389,"Hard Rock Stadium","outdoors"),
"MIN":(44.9738,-93.2575,"U.S. Bank Stadium","dome"),"NE":(42.0909,-71.2643,"Gillette Stadium","outdoors"),
"NO":(29.9511,-90.0812,"Caesars Superdome","dome"),"NYG":(40.8135,-74.0745,"MetLife Stadium","outdoors"),
"NYJ":(40.8135,-74.0745,"MetLife Stadium","outdoors"),"PHI":(39.9008,-75.1675,"Lincoln Financial Field","outdoors"),
"PIT":(40.4468,-80.0158,"Acrisure Stadium","outdoors"),"SF":(37.4033,-121.9694,"Levi's Stadium","outdoors"),
"SEA":(47.5952,-122.3316,"Lumen Field","outdoors"),"TB":(27.9759,-82.5033,"Raymond James Stadium","outdoors"),
"TEN":(36.1665,-86.7713,"Nissan Stadium","outdoors"),"WAS":(38.9077,-76.8645,"Northwest Stadium","outdoors")}
INJURY=re.compile(r"injur|questionable|doubtful|out for|out indefinitely|concussion|hamstring|ankle|knee|shoulder|limited practice|miss(?:es|ing)? (?:the )?game|injured reserve|\\bIR\\b",re.I)
def get(url,timeout=60):
    req=Request(url,headers={"User-Agent":UA,"Accept":"application/json,text/csv,*/*"})
    with urlopen(req,timeout=timeout) as r:return r.read()
def news():
    payload=json.loads(get("https://site.api.espn.com/apis/site/v2/sports/football/nfl/news?limit=60").decode())
    items=[]
    for a in payload.get("articles",[]):
        title=a.get("headline") or a.get("title") or "NFL update"
        summary=re.sub(r"<[^>]+>"," ",a.get("description") or a.get("summary") or "").strip()
        links=a.get("links") or {}
        url=(links.get("web") or {}).get("href") if isinstance(links.get("web"),dict) else None
        url=url or a.get("link") or a.get("url") or "https://www.espn.com/nfl/"
        is_injury=bool(INJURY.search(title+" "+summary))
        items.append({"title":title,"summary":summary[:700],"url":url,"publishedAt":a.get("published") or a.get("lastModified") or "",
          "source":"ESPN","category":"injury" if is_injury else "news","categoryLabel":"INJURY WATCH" if is_injury else "NFL NEWS"})
    if not items: raise RuntimeError("ESPN news returned zero articles; refusing to publish empty feed.")
    seen=set();out=[]
    for a in items:
        k=(a["title"],a["url"])
        if k not in seen:seen.add(k);out.append(a)
    return {"generatedAt":datetime.now(timezone.utc).isoformat(),"source":"ESPN NFL news","items":out}
def games():
    raw=get("https://raw.githubusercontent.com/nflverse/nfldata/master/data/games.csv",90).decode("utf-8-sig")
    rows=list(csv.DictReader(io.StringIO(raw)))
    today=date.today();out=[]
    for r in rows:
        try:
            if int(r.get("season") or 0)!=2026 or r.get("game_type","REG") not in ("REG","POST"):continue
            d=date.fromisoformat((r.get("gameday") or "")[:10])
            if d<today or d>today+timedelta(days=18):continue
            home=(r.get("home_team") or "").upper();away=(r.get("away_team") or "").upper()
            if home not in STADIUMS or away not in STADIUMS:continue
            lat,lon,stadium,roof=STADIUMS[home]
            gid=r.get("game_id") or f"2026_{r.get('week')}_{away}_{home}"
            out.append({"gameId":gid,"season":2026,"week":r.get("week","?"),"date":d.isoformat(),"time":(r.get("gametime") or "TBD"),
             "homeTeam":home,"awayTeam":away,"stadium":stadium,"roof":roof,"latitude":lat,"longitude":lon})
        except Exception:continue
    out.sort(key=lambda x:(x["date"],x["time"]))
    if not out:raise RuntimeError("Schedule downloaded but no upcoming games found.")
    return out
def forecast(g):
    if g["roof"] in ("dome","closed"):return {"available":False,"reason":"Indoor/closed-roof stadium; outdoor weather has less direct effect."}
    if date.fromisoformat(g["date"])>date.today()+timedelta(days=16):return {"available":False,"reason":"Too far ahead for an hourly forecast. Check again within 16 days of kickoff."}
    params={"latitude":g["latitude"],"longitude":g["longitude"],"hourly":"temperature_2m,precipitation_probability,wind_speed_10m,wind_gusts_10m,weather_code","temperature_unit":"fahrenheit","wind_speed_unit":"mph","timezone":"auto","forecast_days":16}
    payload=json.loads(get("https://api.open-meteo.com/v1/forecast?"+urlencode(params)).decode())
    h=payload.get("hourly",{});times=h.get("time",[])
    try:hh,mm=map(int,g["time"][:5].split(":"));desired=hh*60+mm
    except Exception:desired=13*60
    candidates=[]
    for i,t in enumerate(times):
        if t[:10]!=g["date"]:continue
        try:th,tm=map(int,t[11:16].split(":"));candidates.append((abs(th*60+tm-desired),i,t))
        except Exception:pass
    if not candidates:return {"available":False,"reason":"Kickoff forecast hour not available yet."}
    _,i,t=min(candidates)
    def v(k):return h.get(k,[None]*len(times))[i]
    code=v("weather_code");desc={0:"Clear",1:"Mostly clear",2:"Partly cloudy",3:"Overcast",45:"Fog",48:"Freezing fog",51:"Light drizzle",53:"Drizzle",55:"Heavy drizzle",61:"Light rain",63:"Rain",65:"Heavy rain",71:"Light snow",73:"Snow",75:"Heavy snow",80:"Rain showers",81:"Rain showers",82:"Heavy showers",95:"Thunderstorm",96:"Thunderstorm with hail",99:"Severe thunderstorm"}
    return {"available":True,"temperatureF":v("temperature_2m"),"precipitationProbability":v("precipitation_probability"),"windMph":v("wind_speed_10m"),"gustMph":v("wind_gusts_10m"),"weatherCode":code,"summary":desc.get(code,"Forecast"),"localTime":t[11:16],"source":"Open-Meteo"}
def main():
    ROOT.mkdir(exist_ok=True)
    n=news();gs=games();wx={}
    for g in gs:
        try:wx[g["gameId"]]=forecast(g)
        except Exception as e:
            print("Weather fetch failed",g["gameId"],str(e))
            wx[g["gameId"]]={"available":False,"reason":"Forecast temporarily unavailable; check again later."}
        time.sleep(.12)
    (ROOT/"news.json").write_text(json.dumps(n,separators=(",",":")),encoding="utf-8")
    (ROOT/"weather.json").write_text(json.dumps({"generatedAt":datetime.now(timezone.utc).isoformat(),"source":"nflverse schedule + Open-Meteo","games":gs,"forecasts":wx},separators=(",",":")),encoding="utf-8")
    print("Built",len(n["items"]),"news stories and",len(gs),"upcoming games.")
if __name__=="__main__":main()
